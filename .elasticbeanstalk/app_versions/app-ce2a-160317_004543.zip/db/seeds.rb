# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
# Spree::Core::Engine.load_seed if defined?(Spree::Core)
# Spree::Auth::Engine.load_seed if defined?(Spree::Auth)
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)

# 7.times do
# 	Spree::FeatureMenuSubitem.create(spree_feature_menu_head_id: 1, item: "subItem", url: "abx")
# end

# 8.times do
# 	Spree::FeatureMenuSubitem.create(spree_feature_menu_head_id: 2, item: "subItem", url: "abx")
# end

# 6.times do
# 	Spree::FeatureMenuSubitem.create(spree_feature_menu_head_id: 3, item: "subItem", url: "abx")
# end

# 8.times do
# 	Spree::FeatureMenuSubitem.create(spree_feature_menu_head_id: 4, item: "subItem", url: "abx")
# end

