class Testimonial < ActiveRecord::Base
  belongs_to :spree_user
end
