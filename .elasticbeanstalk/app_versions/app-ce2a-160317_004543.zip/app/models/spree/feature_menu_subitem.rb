module Spree
  class FeatureMenuSubitem < Spree::Base
  end
end
