module Spree
  class FeatureMenuHead < Spree::Base
  end
end
