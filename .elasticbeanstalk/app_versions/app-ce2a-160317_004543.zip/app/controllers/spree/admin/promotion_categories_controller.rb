module Spree
  module Admin
    class PromotionCategoriesController < ResourceController
    end
  end
end
