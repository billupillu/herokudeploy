module Spree
  module Admin
    class ShippingCategoriesController < ResourceController
    end
  end
end
