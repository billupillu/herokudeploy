module Spree
  module Admin
    class RolesController < ResourceController
    end
  end
end
