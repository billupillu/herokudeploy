module Spree
  module Admin
    class ReimbursementTypesController < ResourceController
    end
  end
end
