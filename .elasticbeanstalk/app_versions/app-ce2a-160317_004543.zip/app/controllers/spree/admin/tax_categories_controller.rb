module Spree
  module Admin
    class TaxCategoriesController < ResourceController
    end
  end
end
